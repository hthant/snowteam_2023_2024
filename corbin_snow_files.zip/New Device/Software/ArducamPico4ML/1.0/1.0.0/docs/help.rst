Getting Help and Contributing
=============================

This is a community supported project and has multiple ways to get assistance.
Posting complete details, in a polite and organized way will get the best
response.

For bugs in the Core, or to submit patches, please use the
`GitHub Issues <https://github.com/earlephilhower/arduino-pico/issues>`_ or
`GitHub Pull Requests <https://github.com/earlephilhower/arduino-pico/pulls>`_

For general questions/discussions use either
`GitHub Discussions <https://github.com/earlephilhower/arduino-pico/discussions>`_
or live-chat with `gitter.im <https://gitter.im/arduino-pico/community>`_

